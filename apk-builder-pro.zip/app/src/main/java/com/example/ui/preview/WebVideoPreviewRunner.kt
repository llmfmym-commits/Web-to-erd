package com.example.ui.preview

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.ApkProjectConfig
import com.example.model.AppSourceType

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebVideoPreviewRunner(
    config: ApkProjectConfig,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by remember { mutableStateOf("") }
    var pageTitle by remember { mutableStateOf(config.appName) }
    var isLoading by remember { mutableStateOf(false) }
    var loadProgress by remember { mutableStateOf(0) }
    var canGoBack by remember { mutableStateOf(false) }
    var isDesktopMode by remember { mutableStateOf(config.userAgentDesktop) }

    // Fullscreen video state
    var isCustomVideoActive by remember { mutableStateOf(false) }
    var customVideoView by remember { mutableStateOf<View?>(null) }
    var customVideoCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    // Tapsell ad simulation states
    var showInterstitialDialog by remember { mutableStateOf(false) }
    var showRewardedDialog by remember { mutableStateOf(false) }
    var rewardedSecondsLeft by remember { mutableStateOf(5) }
    var isTapsellBannerVisible by remember { mutableStateOf(config.tapsellConfig.enabled) }

    BackHandler {
        if (isCustomVideoActive) {
            customVideoCallback?.onCustomViewHidden()
            isCustomVideoActive = false
            customVideoView = null
        } else if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            onClose()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F172A))) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Navigation & Control Bar
            Surface(
                color = Color(0xFF1E293B),
                tonalElevation = 4.dp,
                shadowElevation = 4.dp
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onClose) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "بستن پیش‌نمایش",
                                tint = Color.White
                            )
                        }

                        IconButton(
                            onClick = { webViewInstance?.goBack() },
                            enabled = canGoBack
                        ) {
                            Icon(
                                Icons.Default.ArrowForward,
                                contentDescription = "صفحه قبل",
                                tint = if (canGoBack) Color.White else Color.Gray
                            )
                        }

                        IconButton(
                            onClick = { webViewInstance?.reload() }
                        ) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "بازنشانی",
                                tint = Color(0xFF38BDF8)
                            )
                        }

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = pageTitle.ifBlank { config.appName },
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            Text(
                                text = if (config.sourceType == AppSourceType.PUBLIC_URL) currentUrl.ifBlank { config.sourceUrl } else "محتوای HTML5 داخلی",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        }

                        // Desktop Mode Switch
                        IconButton(
                            onClick = {
                                isDesktopMode = !isDesktopMode
                                webViewInstance?.settings?.userAgentString = if (isDesktopMode) {
                                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                                } else null
                                webViewInstance?.reload()
                            }
                        ) {
                            Icon(
                                if (isDesktopMode) Icons.Default.Computer else Icons.Default.PhoneAndroid,
                                contentDescription = "حالت دسکتاپ/موبایل",
                                tint = if (isDesktopMode) Color(0xFF10B981) else Color.White
                            )
                        }

                        // Trigger Ad Buttons if Tapsell enabled
                        if (config.tapsellConfig.enabled) {
                            IconButton(
                                onClick = { showInterstitialDialog = true }
                            ) {
                                Icon(
                                    Icons.Default.Campaign,
                                    contentDescription = "تست تبلیغ بین‌برنامه‌ای",
                                    tint = Color(0xFFF59E0B)
                                )
                            }
                        }
                    }

                    // Progress Bar
                    if (isLoading) {
                        LinearProgressIndicator(
                            progress = { loadProgress / 100f },
                            modifier = Modifier.fillMaxWidth().height(3.dp),
                            color = Color(0xFF0284C7),
                            trackColor = Color(0xFF334155)
                        )
                    }
                }
            }

            // Main Web & Video Frame
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )

                            settings.apply {
                                javaScriptEnabled = config.enableJavaScript
                                domStorageEnabled = true
                                databaseEnabled = true
                                allowFileAccess = config.allowFileAccess
                                mediaPlaybackRequiresUserGesture = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    isLoading = true
                                    currentUrl = url ?: ""
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    isLoading = false
                                    currentUrl = url ?: ""
                                    pageTitle = view?.title ?: config.appName
                                    canGoBack = view?.canGoBack() ?: false
                                }

                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    return false
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    loadProgress = newProgress
                                    if (newProgress == 100) isLoading = false
                                }

                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank()) pageTitle = title
                                }

                                // Fullscreen Video support
                                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                                    customVideoView = view
                                    customVideoCallback = callback
                                    isCustomVideoActive = true
                                }

                                override fun onHideCustomView() {
                                    isCustomVideoActive = false
                                    customVideoView = null
                                    customVideoCallback?.onCustomViewHidden()
                                }

                                // Grant permission requests (WebRTC microphone/camera)
                                override fun onPermissionRequest(request: PermissionRequest?) {
                                    request?.grant(request.resources)
                                }
                            }

                            webViewInstance = this

                            // Initial load
                            if (config.sourceType == AppSourceType.PUBLIC_URL) {
                                loadUrl(config.sourceUrl)
                            } else {
                                loadDataWithBaseURL("https://local.app/", config.htmlContent, "text/html", "UTF-8", null)
                            }
                        }
                    }
                )

                // Fullscreen Video View overlay
                if (isCustomVideoActive && customVideoView != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black)
                    ) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { _ ->
                                FrameLayout(context).apply {
                                    customVideoView?.let { v ->
                                        if (v.parent != null) (v.parent as ViewGroup).removeView(v)
                                        addView(v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                                    }
                                }
                            }
                        )
                        IconButton(
                            onClick = {
                                customVideoCallback?.onCustomViewHidden()
                                isCustomVideoActive = false
                                customVideoView = null
                            },
                            modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                        ) {
                            Icon(Icons.Default.FullscreenExit, contentDescription = "خروج از تمام‌صفحه", tint = Color.White)
                        }
                    }
                }
            }

            // Tapsell Banner Simulator (if enabled)
            AnimatedVisibility(visible = config.tapsellConfig.enabled && isTapsellBannerVisible) {
                Surface(
                    color = Color(0xFF0369A1),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.White)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("تبلیغ تپسل (Tapsell)", color = Color(0xFF0369A1), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("پیش‌نمایش بنر استاندارد تپسل (۳۲۰×۵۰)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("شناسه زون: ${config.tapsellConfig.bannerZoneId.take(12)}...", color = Color(0xFFBAE6FD), fontSize = 9.sp)
                        }
                        IconButton(onClick = { isTapsellBannerVisible = false }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "بستن بنر", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Interstitial Ad Simulator Dialog
        if (showInterstitialDialog) {
            AlertDialog(
                onDismissRequest = { showInterstitialDialog = false },
                icon = { Icon(Icons.Default.Campaign, contentDescription = null, tint = Color(0xFFF59E0B)) },
                title = { Text("پیش‌نمایش تبلیغ بین‌برنامه‌ای تپسل", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("این دیالوگ شبیه‌ساز نمایش تبلیغ Interstitial تپسل پلاس است.")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("کلید اپلیکیشن: ${config.tapsellConfig.appKey.take(16)}...", fontSize = 11.sp, color = Color.Gray)
                        Text("شناسه زون: ${config.tapsellConfig.interstitialZoneId}", fontSize = 11.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    Button(onClick = { showInterstitialDialog = false }) {
                        Text("بستن تبلیغ")
                    }
                }
            )
        }
    }
}
