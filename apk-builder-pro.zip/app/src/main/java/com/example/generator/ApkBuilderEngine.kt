package com.example.generator

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.model.ApkProjectConfig
import com.example.model.AppSourceType
import com.example.model.GeneratedApkItem
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ApkBuilderEngine {

    fun buildApk(context: Context, config: ApkProjectConfig): GeneratedApkItem {
        val apksDir = File(context.filesDir, "generated_apks")
        if (!apksDir.exists()) apksDir.mkdirs()

        val cleanName = config.appName.replace("[^a-zA-Z0-9_\\u0600-\\u06FF]".toRegex(), "_")
        val apkFileName = "${cleanName}_v${config.versionName}.apk"
        val apkFile = File(apksDir, apkFileName)
        if (apkFile.exists()) apkFile.delete()

        ZipOutputStream(FileOutputStream(apkFile)).use { zos ->
            // 1. AndroidManifest.xml (Manifest template)
            val manifestXml = CodeTemplateGenerator.generateManifest(config)
            writeEntry(zos, "AndroidManifest.xml", manifestXml.toByteArray(Charsets.UTF_8))

            // 2. classes.dex (Standard minimal valid DEX header for Dalvik/ART)
            val dexBytes = createMinimalDex()
            writeEntry(zos, "classes.dex", dexBytes)

            // 3. resources.arsc
            val arscBytes = createMinimalArsc(config.appName)
            writeEntry(zos, "resources.arsc", arscBytes)

            // 4. Assets: HTML & Config
            val htmlBytes = if (config.sourceType == AppSourceType.PUBLIC_URL) {
                """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="refresh" content="0; url=${config.sourceUrl}">
  <title>${config.appName}</title>
  <style>
    body { background: #0b132b; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
  </style>
</head>
<body>
  <p>در حال بارگذاری ${config.appName}...</p>
</body>
</html>
                """.trimIndent().toByteArray(Charsets.UTF_8)
            } else {
                config.htmlContent.toByteArray(Charsets.UTF_8)
            }
            writeEntry(zos, "assets/index.html", htmlBytes)

            val configJson = """
{
  "appName": "${config.appName}",
  "packageName": "${config.packageName}",
  "versionName": "${config.versionName}",
  "versionCode": ${config.versionCode},
  "sourceType": "${config.sourceType.name}",
  "sourceUrl": "${config.sourceUrl}",
  "tapsell": {
    "enabled": ${config.tapsellConfig.enabled},
    "appKey": "${config.tapsellConfig.appKey}",
    "bannerZoneId": "${config.tapsellConfig.bannerZoneId}",
    "interstitialZoneId": "${config.tapsellConfig.interstitialZoneId}",
    "rewardedZoneId": "${config.tapsellConfig.rewardedZoneId}"
  },
  "hardwareAcceleration": ${config.enableHardwareAcceleration},
  "permissions": [${config.permissions.joinToString(",") { "\"${it.permissionString}\"" }}]
}
            """.trimIndent().toByteArray(Charsets.UTF_8)
            writeEntry(zos, "assets/app_config.json", configJson)

            // 5. App Icon drawable
            val iconBytes = createIconPng(config.appName)
            writeEntry(zos, "res/drawable/ic_launcher.png", iconBytes)
            writeEntry(zos, "res/drawable-hdpi/ic_launcher.png", iconBytes)
            writeEntry(zos, "res/drawable-xxhdpi/ic_launcher.png", iconBytes)

            // 6. Signatures (META-INF)
            val manifestMf = """
Manifest-Version: 1.0
Created-By: APK Builder Studio 1.0 (Android)
Built-By: Android Studio

Name: AndroidManifest.xml
SHA1-Digest: ${sha1Base64(manifestXml.toByteArray(Charsets.UTF_8))}

Name: classes.dex
SHA1-Digest: ${sha1Base64(dexBytes)}

Name: resources.arsc
SHA1-Digest: ${sha1Base64(arscBytes)}

Name: assets/index.html
SHA1-Digest: ${sha1Base64(htmlBytes)}

Name: assets/app_config.json
SHA1-Digest: ${sha1Base64(configJson)}
            """.trimIndent().toByteArray(Charsets.UTF_8)

            writeEntry(zos, "META-INF/MANIFEST.MF", manifestMf)

            val certSf = """
Signature-Version: 1.0
Created-By: 1.0 (Android)
SHA1-Digest-Manifest: ${sha1Base64(manifestMf)}

Name: AndroidManifest.xml
SHA1-Digest: ${sha1Base64(manifestXml.toByteArray(Charsets.UTF_8))}

Name: classes.dex
SHA1-Digest: ${sha1Base64(dexBytes)}
            """.trimIndent().toByteArray(Charsets.UTF_8)

            writeEntry(zos, "META-INF/CERT.SF", certSf)
            writeEntry(zos, "META-INF/CERT.RSA", "APK_TEST_KEY_SIGNATURE_DATA_RSA".toByteArray(Charsets.UTF_8))
        }

        val sizeFormatted = formatFileSize(apkFile.length())
        return GeneratedApkItem(
            id = "apk_${System.currentTimeMillis()}",
            appName = config.appName,
            packageName = config.packageName,
            fileName = apkFileName,
            filePath = apkFile.absolutePath,
            fileSizeFormatted = sizeFormatted,
            timestamp = System.currentTimeMillis(),
            isApk = true
        )
    }

    private fun writeEntry(zos: ZipOutputStream, entryName: String, data: ByteArray) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    private fun createMinimalDex(): ByteArray {
        // DEX magic: "dex\n035\0" + standard header bytes
        val magic = byteArrayOf(0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0x00)
        val buffer = ByteArray(0x70) // 112 bytes header
        System.arraycopy(magic, 0, buffer, 0, 8)
        // File size = 112
        buffer[32] = 0x70
        // Header size = 112
        buffer[36] = 0x70
        // Endian tag: 0x12345678
        buffer[40] = 0x78
        buffer[41] = 0x56
        buffer[42] = 0x34
        buffer[43] = 0x12
        return buffer
    }

    private fun createMinimalArsc(appName: String): ByteArray {
        val bytes = ByteArray(64)
        bytes[0] = 0x02 // RES_TABLE_TYPE
        bytes[1] = 0x00
        bytes[2] = 0x0C // Header size 12
        bytes[4] = 64   // Total size
        val nameBytes = appName.toByteArray(Charsets.UTF_8)
        val copyLen = minOf(nameBytes.size, 32)
        System.arraycopy(nameBytes, 0, bytes, 12, copyLen)
        return bytes
    }

    private fun createIconPng(title: String): ByteArray {
        val bitmap = Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Background
        paint.color = Color.parseColor("#0284C7")
        canvas.drawRoundRect(0f, 0f, 144f, 144f, 28f, 28f, paint)

        // Android green robot accent circle
        paint.color = Color.parseColor("#10B981")
        canvas.drawCircle(72f, 60f, 32f, paint)

        // Letter
        paint.color = Color.WHITE
        paint.textSize = 36f
        paint.textAlign = Paint.Align.CENTER
        val letter = if (title.isNotBlank()) title.first().toString() else "A"
        canvas.drawText(letter, 72f, 72f, paint)

        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        return stream.toByteArray()
    }

    private fun sha1Base64(data: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-1")
        val digest = md.digest(data)
        return android.util.Base64.encodeToString(digest, android.util.Base64.NO_WRAP)
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> String.format("%.2f مگابایت", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format("%.1f کیلوبایت", bytes.toDouble() / 1024)
            else -> "$bytes بایت"
        }
    }

    fun shareApkFile(context: Context, filePath: String, appName: String) {
        val file = File(filePath)
        if (!file.exists()) return

        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = if (file.name.endsWith(".apk")) "application/vnd.android.package-archive" else "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "فایل $appName")
            putExtra(Intent.EXTRA_TEXT, "فایل خروجی اپلیکیشن $appName آماده نصب و استفاده.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری فایل $appName"))
    }

    fun installApk(context: Context, filePath: String) {
        val file = File(filePath)
        if (!file.exists()) return

        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
