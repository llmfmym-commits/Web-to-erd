package com.example.model

enum class AppSourceType(val titleFa: String, val descFa: String) {
    PUBLIC_URL("لینک عمومی (Web URL)", "تبدیل هر آدرس اینترنتی یا وب‌سایت به اپلیکیشن اختصاصی"),
    HTML_CODE("کد / سند HTML", "کدهای HTML5، CSS، JS و فایل‌های محلی به همراه مدیا"),
    HTML_FILE("فایل HTML", "بارگذاری مستقیم فایل HTML از حافظه دستگاه"),
    PROJECT_ZIP("فایل ZIP پروژه", "تبدیل سورس پروژه خام کاتلین یا جاوا به همراه پکیج اختصاصی")
}

enum class LanguageType(val displayName: String, val extension: String) {
    KOTLIN("Kotlin", "kt"),
    JAVA("Java", "java")
}

enum class AppPermission(
    val permissionString: String,
    val titleFa: String,
    val descFa: String,
    val isDangerous: Boolean
) {
    INTERNET(
        "android.permission.INTERNET",
        "اینترنت (Internet)",
        "دسترسی به شبکه و بارگذاری صفحات وب و ویدیوهای آنلاین",
        false
    ),
    RECORD_AUDIO(
        "android.permission.RECORD_AUDIO",
        "میکروفون (Microphone)",
        "ضبط صدا، ارسال پیام صوتی یا چت صوتی در وب‌سایت",
        true
    ),
    CAMERA(
        "android.permission.CAMERA",
        "دوربین (Camera)",
        "عکسبرداری، تماس ویدیویی و اسکن مدارک در وب‌ویو",
        true
    ),
    STORAGE(
        "android.permission.READ_MEDIA_IMAGES",
        "گالری و حافظه (Storage)",
        "دانلود فایل‌ها یا آپلود تصاویر از گالری کاربر",
        true
    ),
    LOCATION(
        "android.permission.ACCESS_FINE_LOCATION",
        "موقعیت مکانی (Location / GPS)",
        "مکان‌یابی کاربر و پشتیبانی از نقشه در صفحات وب",
        true
    ),
    NOTIFICATIONS(
        "android.permission.POST_NOTIFICATIONS",
        "اعلان‌ها (Notifications)",
        "ارسال نوتیفیکیشن‌های فشاری (Push Notifications) به کاربر",
        true
    ),
    VIBRATE(
        "android.permission.VIBRATE",
        "ویبره (Vibration)",
        "لرزش گوشی برای دکمه‌ها و رویدادهای وب",
        false
    ),
    MODIFY_AUDIO(
        "android.permission.MODIFY_AUDIO_SETTINGS",
        "تنظیم صدا (Audio Settings)",
        "کنترل دقیق بلندی و خروجی صدای ویدیو و موسیقی",
        false
    )
}

data class TapsellConfig(
    val enabled: Boolean = true,
    val appKey: String = "skjhqwiouyqwhkjasdhfkhsdafjkhasdkjfhkasdjf",
    val bannerZoneId: String = "65a123bcdef0123456789abc",
    val interstitialZoneId: String = "65a987fedcba987654321cba",
    val rewardedZoneId: String = "65a456abcdef123456789012"
)

data class ApkProjectConfig(
    val id: String = "proj_default",
    val appName: String = "اپلیکیشن من",
    val packageName: String = "com.myapp.webview",
    val versionName: String = "1.0.0",
    val versionCode: Int = 1,
    val sourceType: AppSourceType = AppSourceType.PUBLIC_URL,
    val sourceUrl: String = "https://www.aparat.com",
    val htmlContent: String = DEFAULT_HTML_TEMPLATE,
    val projectZipName: String? = null,
    val customLogoName: String = "ic_default_logo",
    val customLogoBase64: String? = null,
    val language: LanguageType = LanguageType.KOTLIN,
    val permissions: Set<AppPermission> = setOf(
        AppPermission.INTERNET,
        AppPermission.RECORD_AUDIO,
        AppPermission.CAMERA,
        AppPermission.VIBRATE
    ),
    val tapsellConfig: TapsellConfig = TapsellConfig(),
    val enableHardwareAcceleration: Boolean = true,
    val enableJavaScript: Boolean = true,
    val enableVideoFullscreen: Boolean = true,
    val allowFileAccess: Boolean = true,
    val userAgentDesktop: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class GeneratedApkItem(
    val id: String,
    val appName: String,
    val packageName: String,
    val fileName: String,
    val filePath: String,
    val fileSizeFormatted: String,
    val timestamp: Long,
    val isApk: Boolean
)

val DEFAULT_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>برنامه وب و ویدیویی من</title>
  <style>
    body {
      margin: 0;
      padding: 16px;
      font-family: system-ui, -apple-system, sans-serif;
      background: #0f172a;
      color: #f8fafc;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
      box-sizing: border-box;
    }
    .card {
      background: #1e293b;
      border-radius: 16px;
      padding: 20px;
      max-width: 500px;
      width: 100%;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
      border: 1px solid #334155;
      margin-bottom: 20px;
    }
    h1 {
      font-size: 1.4rem;
      color: #38bdf8;
      margin-top: 0;
    }
    p {
      color: #94a3b8;
      font-size: 0.95rem;
      line-height: 1.6;
    }
    video {
      width: 100%;
      border-radius: 12px;
      background: #000;
      margin-top: 10px;
      outline: none;
    }
    .btn {
      background: #0284c7;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 8px;
      font-size: 0.9rem;
      cursor: pointer;
      margin-top: 12px;
      transition: background 0.2s;
    }
    .btn:active {
      background: #0369a1;
    }
    .badge {
      display: inline-block;
      background: #10b98122;
      color: #10b981;
      border: 1px solid #10b98144;
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">آماده برای تبدیل به APK</span>
    <h1>پخش‌کننده ویدیو و وب نسخه اندروید</h1>
    <p>این یک سند پیش‌فرض HTML5 با قابلیت پخش مستقیم ویدیو، ضبط صدا و تعامل کامل لمسی است.</p>
    
    <video controls playsinline poster="https://picsum.photos/600/340">
      <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4">
      مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
    </video>

    <button class="btn" onclick="requestMic()">تست اجازه دسترسی به میکروفون</button>
    <div id="micStatus" style="margin-top: 8px; font-size: 0.85rem; color: #38bdf8;"></div>
  </div>

  <script>
    function requestMic() {
      const status = document.getElementById('micStatus');
      status.innerText = "درخواست دسترسی به میکروفون در حال ارسال به اندروید...";
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ audio: true })
          .then(stream => {
            status.innerText = "✅ مجوز میکروفون با موفقیت دریافت شد!";
            status.style.color = "#10b981";
          })
          .catch(err => {
            status.innerText = "⚠️ مجوز میکروفون رد شد یا نیاز به تایید دارد: " + err.message;
            status.style.color = "#f43f5e";
          });
      } else {
        status.innerText = "وب‌ویو از MediaDevices پشتیبانی می‌کند.";
      }
    }
  </script>
</body>
</html>
""".trimIndent()
